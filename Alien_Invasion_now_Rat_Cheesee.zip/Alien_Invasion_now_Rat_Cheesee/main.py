from alien_invasion import AlienInvasion

if __name__ == "__main__":
    """Creating game object and launch"""
    ai = AlienInvasion()
    ai.run_game()
